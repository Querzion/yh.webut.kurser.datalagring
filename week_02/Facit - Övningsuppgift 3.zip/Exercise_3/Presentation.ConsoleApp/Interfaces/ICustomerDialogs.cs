﻿namespace Presentation.ConsoleApp.Interfaces;

public interface ICustomerDialogs
{
    Task MenuOptions();
}