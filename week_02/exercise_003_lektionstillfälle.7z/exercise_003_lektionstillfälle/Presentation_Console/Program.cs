﻿using Infrastructure.Contexts;
using Infrastructure.Interfaces;
using Infrastructure.Repositories;
using Infrastructure.Services;
using Microsoft.Extensions.DependencyInjection;
using Presentation_Console.Dialogs;

var services = new ServiceCollection()
    .AddDbContext<DataContext>(x => x.UseSqLite(""));
    .AddScoped<ICustomerRepository, CustomerRepository>();
    .AddScoped<ICustomerService, CustomerService>();
    .AddScoped<ICustomerDialogs, CustomerDialogs>();
    .BuildServiceProvider();

    var customerDialogs = services.GetRequiredService<ICustomerDialogs>();
    await customerDialogs.MenuOptions();